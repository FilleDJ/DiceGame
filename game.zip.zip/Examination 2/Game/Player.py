import pickle


class player:
    def __init__(self, name, score):
        self.name = name
        self.score = score

    def set_player_name(self, name):
        self.name = name
        return self


def save_player(player, filename):
    try:
        with open(filename, 'rb') as file:
            players = pickle.load(file)
    except (OSError, IOError, EOFError):
        players = []

    player_already_exists = False
    for p in players:
        if p == player:
            player_already_exists = True
            break

    if not player_already_exists:
        players.append(player)
        with open(filename, 'wb') as file:
            pickle.dump(players, file)
    else:
        print(f"{player} already exists in the {filename} file.")


def clear_file(filename):
    with open(filename, 'wb') as f:
        pass


def update_player_score(player_name):
    try:
        with open("players.bin", 'rb') as f:
            players = pickle.load(f)
        for player in players:
            if player.name == player_name:
                player.score = int(player.score)
                player.score = player.score + 1
        with open("players.bin", 'wb') as f:
            pickle.dump(players, f)
    except EOFError:
        pass


def update_player_name(player_name, new_name):
    try:
        with open("players.bin", 'rb') as f:
            players = pickle.load(f)
        for player in players:
            if player.name == player_name:
                player.name = new_name
        with open("players.bin", 'wb') as f:
            pickle.dump(players, f)
    except EOFError:
        pass


def get_player_by_name(player_name):
    try:
        with open("players.bin", 'rb') as f:
            players = pickle.load(f)
        for player in players:
            if player.name == player_name:
                return player
        return None
    except EOFError:
        pass


def get_player_score(name, filename):
    with open(filename, 'rb') as file:
        players = pickle.load(file)
    for player in players:
        if player.name == name:
            return player.score

    return None


def print_all_players():
    try:
        with open("players.bin", "rb") as file:
            players = pickle.load(file)
        for player in players:
            print(f"{player.name} : {player.score}")
    except (OSError, IOError, EOFError):
        print("No scoreboard found")
