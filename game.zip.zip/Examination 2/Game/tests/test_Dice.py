# import unittest
# from Dice import dice_hand
# from Dice import dice_hand_cheat
# import Dice

# class TestDice(unittest.TestCase):
#     def test_dice_hand(self):
#         assert dice_hand("Janne") == 1 or 2 or 3 or 4 or 5 or 6
#         assert dice_hand("Janne") != 0
#         assert dice_hand("Janne") != 7


#     def test_dice_hand_cheat(self):
#         assert dice_hand_cheat("Janne") == 50 or 51 or 52 or 53 or 54 or 55
#         assert dice_hand_cheat("Janne") != 49
#         assert dice_hand_cheat("Janne") != 56


#     def test_roll_dice(self):
#         result = Dice.dice.roll_dice(self) != str
#         result2 = Dice.dice.roll_dice(self) == 1 or 2 or 3 or 4 or 5 or 6
#         assert result
#         assert result2
