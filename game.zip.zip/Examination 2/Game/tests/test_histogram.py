# import unittest
# from Histogram import open_games
# from Histogram import save_game

# def test_save_game():
#     save_game
#     assert save_game != None

# def test_open_games():
#     open_games()
#     assert open_games != None