# import unittest
# import Player
# from unittest.mock import MagicMock


# class TestPlayer(unittest.TestCase):
#     def test_set_player_name(self):
#         result = Player.player.set_player_name(self, "Janne")
#         assert result != None
#         assert result == self
#         self.assertEqual(self, result)

#     def test_set_player_name2(self):
#         result = Player.player.set_player_name(self, "Lisa")
#         assert result != None
#         assert result == self
#         self.assertEqual(self, result)


# if __name__ == "__main__":
#     unittest.main()
