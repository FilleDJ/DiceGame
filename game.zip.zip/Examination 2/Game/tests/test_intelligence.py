# from Intelligence import create_bot
# from Intelligence import bot_play_easy
# from Intelligence import bot_play_hard



# def test_create_bot_default():
#     assert create_bot() != "Computer"
#     assert create_bot() != 0


# def test_bot_play_easy():
#     assert bot_play_easy != 7
#     assert bot_play_easy != 0


# def test_bot_play_hard():
#     assert bot_play_hard != 7
#     assert bot_play_hard != 0
