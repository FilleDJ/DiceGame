from Gameround import bot_round
from Gameround import multiplayerround
from Gameround import bot_round_hard
from Gameround import bot_round_cheat
from Menu import menu1
from Menu import game_mode_menu
from Menu import game_rules
from Menu import choose_profile
from Menu import choose_difficulty
from Player import player
from Player import clear_file
from Player import print_all_players
from Player import get_player_by_name
from Player import update_player_score
from Player import save_player
from Player import update_player_name
from Histogram import save_game
from Histogram import open_games
from Intelligence import create_bot






def bot_game(player1):
    bot = create_bot()
    Winner = bot_round(player1, bot)
    if Winner == player1.name:
        update_player_score(player1.name)


    elif Winner == bot.name:
        bot.score = bot.score + 1
    winner = get_player_by_name(Winner)
    scoren = f'{player1.name} : {winner.score} - {bot.score} : {bot.name}'
    print(scoren)
    save_game(player1, bot, scoren)




def bot_game_cheat(player1):
    bot = create_bot()
    Winner = bot_round_cheat(player1, bot)
    if Winner == player1.name:
        update_player_score(player1.name)


    elif Winner == bot.name:
        bot.score = bot.score + 1
    winner = get_player_by_name(Winner)
    scoren = f'{player1.name} : {winner.score} - {bot.score} : {bot.name}'
    print(scoren)
    save_game(player1, bot, scoren)




def bot_game_hard(player1):
    bot = create_bot()
    Winner = bot_round_hard(player1, bot)
    if Winner == player1.name:
        update_player_score(player1.name)


    elif Winner == bot.name:
        bot.score = bot.score + 1
    scoren = f'{player1.name} : {player1.score} - {bot.score} : {bot.name}'
    print(scoren)
    save_game(player1, bot, scoren)




def multiplayer(player1, player2):
    Winner = multiplayerround(player1, player2)
    if Winner == player1.name:
        player1.score = player1.score + 1
        update_player_score(player1.name)
    elif Winner == player2.name:
        player2.score = player2.score + 1
        update_player_score(player2.name)
    p1 = get_player_by_name(player1.name)
    p2 = get_player_by_name(player2.name)
    scoren = f'{p1.name} : {p1.score} - {p2.score} : {p2.name}'
    print(scoren)
    save_game(player1, player2, scoren)




def main():
    while True:
        choice = menu1()
        print(choice)
        if choice == 1:
            choice = game_mode_menu()
            print(choice)
            if choice == 1:
                choice = choose_profile()
                if choice == 1:
                    playername = input("Enter your name ")
                    player1 = player(playername, 0)
                    save_player(player1, "players.bin")
                    choice = choose_difficulty()
                    if choice == 1:
                        bot_game(player1)
                    elif choice == 2:
                        bot_game_hard(player1)
                    elif choice == 100:
                        bot_game_cheat(player1)
                elif choice == 2:
                    playername = input("Player name ")
                    try:
                        player1 = get_player_by_name(playername)
                        bot_game(player1)
                    except AttributeError:
                        print("No saved player with such a name")
                        pass
                else:
                    print("Invalid Input")
            elif choice == 2:
                playername = input("Enter first player name ")
                player1 = player(playername, 0)
                save_player(player1, "players.bin")
                playername1 = input("Enter second player name ")
                player2 = player(playername1, 0)
                save_player(player2, "players.bin")
                multiplayer(player1, player2)
            else:
                print("Invalid Input")
        elif choice == 2:
            open_games()
        elif choice == 3:
            print_all_players()
        elif choice == 4:
            game_rules()
        elif choice == 5:
            clear_file("players.bin")
            clear_file("gamehistory.bin")
        elif choice == 6:
            namechange = input("Enter existing name ")
            new_name = input("Enter new name ")
            try:
                update_player_name(namechange, new_name)
            except AttributeError:
                print(f'No saved player named {namechange}')
        elif choice == 7:
            print("Quitting....")
            break
        elif choice != int:
            print("Invalid Input")
        else:
            print("Invalid Input")




if __name__ == '__main__':
    main()
