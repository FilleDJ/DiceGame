from Menu import current_round
from Dice import dice_hand
from Dice import dice_hand_cheat
from Intelligence import bot_play_easy
from Intelligence import bot_play_hard




def bot_round(player1, player2):
    try:
        print(f"{player1}'s turn!")
        score = dice_hand(player1.name)
        choice = current_round()
        lista = []
        final_score = 0
        if choice == 1:
            score2 = dice_hand(player1.name)
            choice = current_round()
            print(f'Current score: {score2}')
            lista.append(score)
            lista.append(score2)
            while choice == 1:
                score3 = dice_hand(player1.name)
                lista.append(score3)
                choice = current_round()
            print(f"{player2.name}'s turn!")
            botplay = bot_play_easy(player2)
            print(f"{player2.name} scores a {botplay}")
        elif choice == 2:
            print(f"{player2.name}'s turn!")
            botplay = bot_play_easy(player2)
            print(f"{player2.name} scores a {botplay}")
        elif choice == 3:
            pass
        for f in lista:
            final_score = final_score + f
            if f == 1:
                final_score = 0
        print(f"{player1.name} scores a {final_score}")
        if final_score > botplay:
            print(f'{player1.name} wins the round!')
            return player1.name
        else:
            print(f'{player2.name} wins the round!')
            return player2.name
    except UnboundLocalError:
        pass




def bot_round_cheat(player1, player2):
    try:
        print(f"{player1}'s turn!")
        score = dice_hand_cheat(player1.name)
        choice = current_round()
        lista = []
        final_score = 0
        if choice == 1:
            score2 = dice_hand_cheat(player1.name)
            choice = current_round()
            print(f'Current score: {score2}')
            lista.append(score)
            lista.append(score2)
            while choice == 1:
                score3 = dice_hand_cheat(player1.name)
                lista.append(score3)
                choice = current_round()
            print(f"{player2.name}'s turn!")
            botplay = bot_play_easy(player2)
            print(f"{player2.name} scores a {botplay}")
        elif choice == 2:
            print(f"{player2.name}'s turn!")
            botplay = bot_play_easy(player2)
            print(f"{player2.name} scores a {botplay}")
        elif choice == 3:
            pass
        for f in lista:
            final_score = final_score + f
            if f == 1:
                final_score = 0
        print(f"{player1.name} scores a {final_score}")
        if final_score > botplay:
            print(f'{player1.name} wins the round!')
            return player1.name
        else:
            print(f'{player2.name} wins the round!')
            return player2.name
    except UnboundLocalError:
        pass




def bot_round_hard(player1, player2):
    print(f"{player1}'s turn!")
    score = dice_hand(player1.name)
    choice = current_round()
    lista = []
    final_score = 0
    if choice == 1:
        score2 = dice_hand(player1.name)
        choice = current_round()
        print(f'Current score: {score2}')
        lista.append(score)
        lista.append(score2)
        while choice == 1:
            score3 = dice_hand(player1.name)
            lista.append(score3)
            choice = current_round()
        print(f"{player2.name}'s turn!")
        botplay = bot_play_hard(player2)
        print(f"{player2.name} scores a {botplay}")
    elif choice == 2:
        print(f"{player2.name}'s turn!")
        botplay = bot_play_hard(player2)
        print(f"{player2.name} scores a {botplay}")
    for f in lista:
        final_score = final_score + f
        if f == 1:
            final_score = 0
    print(f"{player1.name} scores a {final_score}")
    if final_score > botplay:
        print(f'{player1.name} wins the round!')
        return player1
    else:
        print(f'{player2.name} wins the round!')
        return player2.name




def multiplayerround(player1, player2):
    print(f"{player1.name}'s turn!")
    score = dice_hand(player1.name)
    choice = current_round()
    lista = []
    final_score = 0
    if choice == 1:
        score2 = dice_hand(player1.name)
        print(f'Current score: {score2}')
        lista.append(score)
        lista.append(score2)
        choice = current_round()
        while choice == 1:
            score3 = dice_hand(player1.name)
            lista.append(score3)
            choice = current_round()
        print(f"{player2.name}'s turn!")
    # elif choice == 2:
        scorep = dice_hand(player2.name)
        choice = current_round()
        listap = []
        final_scorep = 0
        if choice == 1:
            score2p = dice_hand(player2.name)
            choice = current_round()
            print(f'Current score: {score2p}')
            lista.append(scorep)
            lista.append(score2p)
            while choice == 1:
                score3p = dice_hand(player2.name)
                listap.append(score3p)
                choice = current_round()
        for f in lista:
            final_score = final_score + f
            if f == 1:
                final_score = 0
        for g in listap:
            final_scorep = final_scorep + g
            if g == 1:
                final_scorep = 0
        if final_score > final_scorep:
            print(f'{player1.name} wins the round!')
            return player1
        else:
            print(f'{player2.name} wins the round!')
            return player2
