import pickle


def save_game(player, player2, score):
    try:
        with open("gamehistory.bin", 'rb') as file:
            Games = pickle.load(file)
            Thisgame = []


            Thisgame.append(score)
            Games.append(Thisgame)
    except (OSError, IOError, EOFError):
        Games = []
        Thisgame = []


        Thisgame.append(score)
        Games.append(Thisgame)


    with open("gamehistory.bin", 'wb') as file:
        pickle.dump(Games, file)


def open_games():
    try:
        Games = 0
        with open("gamehistory.bin", 'rb') as file:
            Games = pickle.load(file)
        for i in Games:
            print(i[-1])
    except EOFError:
        print("No gamehistory was found")
    return Games
