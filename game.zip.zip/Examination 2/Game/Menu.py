def menu1():
    print(" 1. New game\n 2. Check game history\n 3. Check Scoreboard\
        \n 4. Game rules\n 5. Reset Memory\n 6. Change name\n 7. Quit")
    choice = input("Enter your choice! ")
    try:
        choice = int(choice)
        return choice
    except ValueError:
        menu1()




def game_mode_menu():
    print("Select gamemode!\n1. Singleplayer\n2. Multiplayer")
    choice = input("Enter your choice! ")
    try:
        choice = int(choice)
        return choice
    except ValueError:
        game_mode_menu()




def current_round():
    print("1. Roll again!\n2. Hold! \n3. Quit")
    choice = input("Enter your choice! ")
    try:
        choice = int(choice)
        return choice
    except ValueError:
        current_round()




def current_game_menu():
    print("1. Continue vs opponent\n2. Exit game!")
    choice = input("Enter your choice! ")
    try:
        choice = int(choice)
        return choice
    except ValueError:
        current_game_menu()



def game_rules():
    print("The game rules is as follows!")
    print("Take turns rolling the dice between 1 and 6")
    print("if u roll 1 then it is opponents turn otherwise you collect")
    print("the points you roll untill you decide to hold.")
    print("If you dont hold on ex. your 3rd roll you hit 1 you get 0 points!")
    print("The player with the highest score wins the game and gets 1 point")




def choose_profile():
    print("Select profile")
    print("1. New profile")
    print("2. Load Profile")
    choice = input("Enter your profile choice! ")
    try:
        choice = int(choice)
        return choice
    except ValueError:
        choose_profile()




def choose_difficulty():
    print("What difficutly do you want to play on? ")
    print("1. Easy! ")
    print("2. Hard! ")
    choice = input("Enter your desired difficulty! ")
    try:
        choice = int(choice)
        return choice
    except ValueError:
        choose_difficulty()
