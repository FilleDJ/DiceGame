import random
from Player import player
from Dice import dice_hand





def create_bot():
    bot = player("Computer", 0)
    return bot




def bot_play_easy(bot):
    score = dice_hand(bot.name)
    final_score = 0
    final_score = final_score + score
    chance = random.randint(1, 5)
    if chance < score:
        add = bot_play_easy(bot)
        final_score = final_score + add
        if add == 1:
            return 0
        elif add != 1:
            return final_score
    if score == 1:
        return 0
    elif score != 1:
        return final_score
    elif final_score == 1:
        return 0




def bot_play_hard(bot):
    score = dice_hand(bot.name)
    final_score = 0
    final_score = final_score + score
    chance = random.randint(1, 2)
    if chance < score:
        add = bot_play_hard(bot)
        final_score = final_score + add
    return final_score
