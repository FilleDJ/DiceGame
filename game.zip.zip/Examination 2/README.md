This is our README for DiceGame "PIG"
==========================================================================================

This code is written by Alexander Pålsson and Filip Danielsson.

==========================================================================================

To run this game we suggest you to play it in your terminal

We have made a menu that will appear for you when you start the program
to navigate this menu we have selected a number for each choice 
which you the user should input considering your desired option.
where you can select to play singleplayer or multiplayer etc.

If you select to play singleplayer mode you will be opted to choose your difficulty
and then to enter your name. Then the game begins where you get presented a
new menu where you can decide to roll again or hold. Then the computer will
play its turn and then the result of the match will be displayed.

if you wish to while selecting difficulty in singleplayer you can input "100" to
activate cheats.

If you decide to play mutiplayer you will be asked to enter both users names
and then you will take turns playing and will have your results displayed
at the end of each match.

After playing a game either singleplayer or multiplayer you can opt to
play again or quit.

If you are uncertain of the game rules you can also opt to have the
rules presented to you from the main menu. 

From the main menu you can also opt to check gamehistory and you
can also check the leaderboard!

If you wish to change your name you can opt to do so in the main menu.

If you wish to reset the leaderboard and the game history you can do so from
 selecting "Reset Memory" in main menu.

==========================================================================================

To run the unit tests for this application you need to do the following:
* Open up the test folder containing all the test files.
* When running the tests you need to uncomment them and run one file with its
corresponding tests at a time. (for some reason the code coverage gets incorrect values otherwise)
* To run the tests when they are uncommented you should enter "python -m pytest" in the terminal
and then the tests should be runned.

==========================================================================================

For our fellow programmers this is how we have structured the code!

We have two Classes one called Dice and the other one called Player.
within these classes we have functions that are meant to have different capabilities
within our program. And instead of doing static classes we have decided to have separate
files with other functions which purpose are to complement and help structure up the code.
so as you will see not everything is in classes.

==========================================================================================

Below we will explain all our functions so you know what they are doing and whats their purpose!

From class dice:
* "def __init__(self, score)" The purpose of this is to be a constructor.
* "def roll_dice(self)" The purpose of this is to simulate rolling a dice to get a number from 1 to 6
and then to return that value.
* "def roll_dice_cheat(self)" The purpose of this is to have a cheat where you can only land high value scores.

from file Dice
* "def dice_hand(player)" The purpose of this is to use the roll_dice function and assign it to a player.
* "def dice_hand_cheat(player)" The purpose of this is to use the roll_dice_cheat function and assign it to a player.

From class player:
* "def __init__(self, name, score)" The purpose of this is to be a constructor.
* "def set_player_name(self, name)" The purpose of this is assign a player name and return it.
* "def save_player(self, player, filename)" The purpose of this is to save the player.
* "def clear_file(filename)" The purpose of this is to clear the file containing all game records.
* "def update_player_score(self, player_name, new_score, filename)" The purpose of this is to update the players score.
* "def get_player_by_name(self, player_name, filename)" The purpose of this is to be able to find the objects name.
* "def get_player_score(self, name, filename)" The purpose of this is to be able to find the objects score.
* "def print_all_players(filename)" The purpose of this is to output all the players from game records.

from file Histogram:
* "def save_game(player1, player2, score)" The purpose of this is to save the game to game records.
* "def open_games()" The purpose of this is to output all game records.

From Menu file
* menu1() This function prints out the main menu, it takes the input from the user and returns it.
* game_mode_menu() This function prints out what type of gamemode the user can choose to play (singleplayer or multiplayer) and returns the users choice.
* current_round() This function prints out the alternatives a player can choose from during a round nad returns the users choice
* current_game_round() This function was ment to present the user with a pause option but was never used, it returns the users choice
* game_rules() This function prints out the rules of the game to the user
* choose_profile() This function prints out and asks the user if they want to use a new player profile or load an old profile and returns the users choice
* choose_difficulty() This function prints out and asks the user what type of intelligence they want to play against when facing the computer in singleplayer mode and returns the users choice

From Intelligence file
* create_bot(bot) creates a player object that represent the bot the player plays against in singleplayer mode.
* bot_play_easy() Simulates the computers turn when playing a round, this function is the easy difficulty version, it takes the bot as parameter
* bot_play_hard() Simulates the computers turn when playing a round, this function is the hard difficulty version, it takes the bot as parameter

==========================================================================================

Writing this project we have used UTF-8, flake8 and PYLINT.

==========================================================================================